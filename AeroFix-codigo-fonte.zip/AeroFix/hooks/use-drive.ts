'use client';
import {useEffect,useRef,useState} from 'react';
import {authorize,chooseDriveItem,prepareGoogle,validConfig,type DriveConfig} from '@/lib/google-auth';
import {createDriveBase,readDriveBase,writeDriveBase,type DriveFile,type DriveSession} from '@/lib/google-drive';
import type {RecordItem} from '@/lib/records';
const CONFIG_KEY='aerofix.google.config.v1';
export function useDrive(onLoad:(records:RecordItem[])=>void,onLocal:()=>void,onMessage:(message:string)=>void){
 const [config,setConfig]=useState<DriveConfig|null>(null),[configLoaded,setConfigLoaded]=useState(false),[sdkReady,setSdkReady]=useState(false),[connected,setConnected]=useState(false),[target,setTarget]=useState<DriveFile|null>(null),[busy,setBusy]=useState(false),[lastSync,setLastSync]=useState('');
 const session=useRef<DriveSession|null>(null),lock=useRef(false);
 useEffect(()=>{let active=true;async function init(){try{const stored=localStorage.getItem(CONFIG_KEY);if(stored){const local=JSON.parse(stored);if(validConfig(local)){if(active)setConfig(local);return;}}}catch{if(active)onMessage('Configure sua conexão Google na seção Drive.');}finally{if(active)setConfigLoaded(true)}}void init();return()=>{active=false}},[]);
 useEffect(()=>{let active=true;setSdkReady(false);if(config)void prepareGoogle().then(()=>{if(active)setSdkReady(true)}).catch(e=>{if(active)onMessage(e.message)});return()=>{active=false}},[config]);
 async function action<T>(task:()=>Promise<T>):Promise<T>{if(lock.current)throw Error('Aguarde a operação atual.');lock.current=true;setBusy(true);try{return await task()}finally{lock.current=false;setBusy(false)}}
 function current(){if(!session.current)throw Error('Conecte sua conta Google primeiro.');if(Date.now()>=session.current.expiresAt-30000)throw Error('Sua conexão expirou. Conecte sua conta novamente e reabra a base.');return session.current;}
 async function connect(){try{await action(async()=>{if(!config)throw Error('Configure sua conexão Google primeiro.');const next=await authorize(config);session.current=next;setConnected(true);setTarget(null);setLastSync('');onLocal();onMessage('Conta autorizada. Abra uma base existente ou escolha uma pasta para criar a sua.');})}catch(e){onMessage((e as Error).message)}}
 async function open(){try{await action(async()=>{const auth=current();const picked=await chooseDriveItem(config!,auth.token,false);if(!picked)return;const result=await readDriveBase(auth,picked.id);setTarget(result.file);onLoad(result.records);setLastSync(new Date().toLocaleTimeString('pt-BR'));onMessage('Base carregada do Google Drive. '+(result.file.capabilities?.canEdit?'Alterações serão salvas neste arquivo.':'Você tem permissão apenas para consultar.'));})}catch(e){onMessage((e as Error).message)}}
 async function create(records:RecordItem[]){try{await action(async()=>{const auth=current();const picked=await chooseDriveItem(config!,auth.token,true);if(!picked)return;const file=await createDriveBase(auth,picked.id,records);setTarget(file);onLoad(records);setLastSync(new Date().toLocaleTimeString('pt-BR'));onMessage('Base criada na pasta escolhida do Google Drive.');})}catch(e){onMessage((e as Error).message)}}
 async function refresh(){try{await action(async()=>{if(!target)return;const result=await readDriveBase(current(),target.id);setTarget(result.file);onLoad(result.records);setLastSync(new Date().toLocaleTimeString('pt-BR'));onMessage('Base atualizada a partir do Drive.');})}catch(e){onMessage((e as Error).message)}}
 async function save(records:RecordItem[]){return action(async()=>{if(!target)throw Error('Escolha uma base no Drive.');const updated=await writeDriveBase(current(),target,records);setTarget({...target,...updated});setLastSync(new Date().toLocaleTimeString('pt-BR'));});}
 function disconnect(){if(busy)return;const token=session.current?.token;session.current=null;setConnected(false);setTarget(null);setLastSync('');onLocal();if(token)window.google?.accounts.oauth2.revoke(token,()=>{});onMessage('Drive desconectado. A base do dispositivo está ativa.');}
 function configure(next:DriveConfig){if(!validConfig(next))throw Error('Confira os três campos. O ID do cliente e o número do projeto devem pertencer ao mesmo projeto Google.');if(busy)throw Error('Aguarde a operação atual.');localStorage.setItem(CONFIG_KEY,JSON.stringify(next));if(connected)disconnect();setConfig(next);onMessage('Configuração salva neste navegador. Agora conecte sua conta Google.');}
 return {config,configLoaded,sdkReady,connected,target,busy,lastSync,connect,open,create,refresh,save,disconnect,configure};
}
export type DriveController=ReturnType<typeof useDrive>;

