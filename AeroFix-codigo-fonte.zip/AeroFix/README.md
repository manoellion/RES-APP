# AeroFix — RES-APP

Aplicativo web de consulta visual de falhas de aerogeradores, feito com React e TypeScript. Cada usuário mantém sua base local ou configura seu próprio Google Drive.

## Publicar no GitHub Pages

Repositório: https://github.com/manoellion/RES-APP

1. Envie o conteúdo desta pasta para a raiz do repositório, na branch `main`. Não envie somente o ZIP.
2. Em **Settings → Pages → Build and deployment → Source**, selecione **GitHub Actions**.
3. Em **Actions**, execute o fluxo **Publicar AeroFix no GitHub Pages**. Novos commits na branch main também publicam automaticamente.
4. Aguarde a conclusão verde do fluxo. O endereço esperado é https://manoellion.github.io/RES-APP/.

A versão não depende de servidor próprio nem de Cloudflare. O GitHub Actions gera os arquivos estáticos em `dist` e os publica pelo Pages.

## Executar no computador

Use Node.js 24 e pnpm 11.19.0:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Abra o endereço indicado pelo terminal, incluindo `/RES-APP/`.

```sh
pnpm test
pnpm build
pnpm preview
```

## Google Drive

Na aba **Drive e backup → Configurar minha conexão**, cada usuário informa seu cliente OAuth Web, número do projeto e chave de API para navegador, todos do mesmo projeto Google Cloud. O app orienta a configuração; não há credenciais incluídas neste repositório.

Para GitHub Pages, registre `https://manoellion.github.io` como origem JavaScript autorizada (sem `/RES-APP/`). Restrinja a chave de navegador às APIs Google Drive e Google Picker e aos sites `https://manoellion.github.io/*` e `https://docs.google.com/*`.

A API de configuração de servidor da versão anterior foi retirada. Nesta versão estática, a configuração é feita no navegador pelo próprio usuário.

A integração precisa de configuração Google Cloud e teste com uma conta real. Permissões corporativas dependem da TI. Os testes incluídos usam respostas simuladas para validar leitura, escrita condicional, conflitos, expiração e validação dos arquivos.

## Seus registros existentes

O armazenamento do navegador pertence ao domínio de cada site. Para levar os registros da versão anterior para o GitHub Pages, exporte o backup no site antigo e importe no novo. Os dados e permissões de arquivos do Drive não são publicados no repositório.

## Limites

O erro 427 é um exemplo fornecido pelo usuário. Não é um diagnóstico validado de fabricante. A base no Drive exige conexão para salvar; não há sincronização em segundo plano. Arquivos JSON: até 5 MB e 2.000 registros.
