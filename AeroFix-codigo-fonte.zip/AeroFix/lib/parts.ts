export const PARTS = [
 {id:'rotor',label:'Rotor e pás',x:30,y:40},
 {id:'gearbox',label:'Gearbox',x:49,y:39},
 {id:'generator',label:'Gerador',x:70,y:38},
 {id:'tower',label:'Torre',x:55,y:75},
 {id:'other',label:'Outros componentes',x:58,y:50},
] as const;
export type PartId = typeof PARTS[number]['id'];
export const normalize=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
export function componentOf(r:{equipment:string;component?:string}):PartId {
 if(PARTS.some(p=>p.id===r.component))return r.component as PartId;
 const value=normalize(r.equipment);
 if(/gearbox|gerabox|caixa multiplicadora|multiplicador/.test(value))return 'gearbox';
 if(/gerador|generator/.test(value)&&!value.includes('aerogerador'))return 'generator';
 if(/rotor|\bpas?\b|pitch|hub/.test(value))return 'rotor';
 if(/torre|tower/.test(value))return 'tower';
 return 'other';
}

