import {parseBase,serializeBase,type RecordItem} from './records';
export type DriveFile={id:string;title:string;etag:string;capabilities?:{canEdit?:boolean};fileSize?:string;mimeType?:string;labels?:{trashed?:boolean}};
export type DriveSession={token:string;expiresAt:number};
export class DriveError extends Error {constructor(message:string,public status=0){super(message);}}
const META='id,title,etag,capabilities(canEdit),fileSize,mimeType,labels(trashed)';
async function request(session:DriveSession,path:string,init:RequestInit={}){
 if(Date.now()>=session.expiresAt-30000)throw new DriveError('Sua conexão expirou. Conecte sua conta novamente e reabra a base.',401);
 let r:Response;
 try{r=await fetch('https://www.googleapis.com/'+path,{...init,headers:{Authorization:'Bearer '+session.token,...init.headers},cache:'no-store',signal:AbortSignal.timeout(30000)});}catch{throw new DriveError('Sem resposta do Google Drive. A alteração não foi confirmada; atualize a base antes de tentar novamente.');}
 if(!r.ok){const message=r.status===401?'Conecte sua conta Google novamente.':r.status===403?'Sua conta não tem permissão para esta operação, ou o administrador bloqueou o acesso.':r.status===404?'Arquivo não encontrado ou sem acesso para esta conta.':r.status===412?'Outra pessoa alterou a base. Suas alterações não foram enviadas. Exporte seu rascunho e atualize a base antes de tentar novamente.':r.status===429?'O Google Drive está limitando as solicitações. Aguarde e tente novamente.':'Não foi possível concluir a operação no Drive. Atualize a base antes de tentar novamente.';throw new DriveError(message,r.status);}
 return r;
}
const url=(id:string)=>'drive/v2/files/'+encodeURIComponent(id)+'?supportsAllDrives=true';
async function metadata(session:DriveSession,id:string):Promise<DriveFile>{const r=await request(session,url(id)+'&fields='+encodeURIComponent(META));const file=await r.json() as DriveFile;if(typeof file.id!=='string'||typeof file.title!=='string'||file.labels?.trashed)throw new DriveError('O arquivo selecionado não está disponível.');return file;}
export async function readDriveBase(session:DriveSession,id:string){
 // Read metadata on both sides of the download; never pair stale data with a newer ETag.
 for(let attempt=0;attempt<2;attempt++){
  const before=await metadata(session,id);
  if(Number(before.fileSize)>5_000_000||before.mimeType?.startsWith('application/vnd.google-apps.'))throw new DriveError('Selecione um arquivo JSON AeroFix de até 5 MB.');
  const response=await request(session,url(id)+'&alt=media');
  const records=parseBase(await response.text());
  const after=await metadata(session,id);
  if(before.etag&&before.etag===after.etag)return {file:after,records};
 }
 throw new DriveError('A base mudou durante a leitura ou não possui controle de versão. Tente abrir novamente.');
}
export async function writeDriveBase(session:DriveSession,file:DriveFile,records:RecordItem[]):Promise<DriveFile>{
 if(!file.capabilities?.canEdit)throw new DriveError('Esta base está disponível apenas para consulta.',403);
 if(!file.etag)throw new DriveError('Não é possível salvar sem verificar a versão do arquivo.');
 const response=await request(session,'upload/drive/v2/files/'+encodeURIComponent(file.id)+'?uploadType=media&supportsAllDrives=true&newRevision=true&fields='+encodeURIComponent(META),{method:'PUT',headers:{'Content-Type':'application/json; charset=UTF-8','If-Match':file.etag},body:serializeBase(records)});
 const updated=await response.json() as DriveFile;
 if(!updated.etag)throw new DriveError('O envio foi recebido, mas a versão não foi confirmada. Atualize a base antes de continuar.');
 return updated;
}
export async function createDriveBase(session:DriveSession,parentId:string,records:RecordItem[]):Promise<DriveFile>{
 const content=serializeBase(records),boundary='aerofix_'+crypto.randomUUID();
 const metadata={title:'AeroFix - base de falhas.json',mimeType:'application/json',parents:[{id:parentId}]};
 const body=`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${content}\r\n--${boundary}--`;
 const response=await request(session,'upload/drive/v2/files?uploadType=multipart&supportsAllDrives=true&fields='+encodeURIComponent(META),{method:'POST',headers:{'Content-Type':'multipart/related; boundary='+boundary},body});
 const file=await response.json() as DriveFile;
 if(!file.id||!file.etag)throw new DriveError('A criação não pôde ser confirmada. Procure a base na pasta antes de criar outra.');
 return file;
}

