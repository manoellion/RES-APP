import {PARTS, type PartId} from './parts';
export type RecordItem = {id:string;equipment:string;code:string;fault:string;cause:string;solution:string;demo?:boolean;component?:PartId};
export function valid(r:unknown):r is RecordItem {
 return !!r && typeof r==='object' && (!('component' in r)||PARTS.some(p=>p.id===(r as RecordItem).component)) && ['id','equipment','code','fault','cause','solution'].every(k=>typeof (r as Record<string,unknown>)[k]==='string' && (r as Record<string,string>)[k].trim().length>0 && (r as Record<string,string>)[k].length<=5000);
}
export function parseBase(text:string):RecordItem[]{
 if(new TextEncoder().encode(text).length>5_000_000)throw Error('A base deve ter até 5 MB.');
 let data: {version?:number;records?:unknown};
 try{data=JSON.parse(text);}catch{throw Error('Este arquivo não contém uma base JSON válida.');}
 if(!data||data.version!==1||!Array.isArray(data.records)||data.records.length>2000||!data.records.every(valid))throw Error('Escolha uma base AeroFix válida, com até 2.000 registros.');
 if(new Set(data.records.map(r=>r.id)).size!==data.records.length)throw Error('A base contém identificadores repetidos. Corrija o arquivo antes de abrir.');
 return data.records.map(({id,equipment,code,fault,cause,solution,component})=>({id,equipment,code,fault,cause,solution,...(component?{component}:{})}));
}
export function serializeBase(records:RecordItem[]){const text=JSON.stringify({version:1,records},null,2);parseBase(text);return text;}
