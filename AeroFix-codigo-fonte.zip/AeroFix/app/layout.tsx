import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'AeroFix — Falhas e soluções',description:'Sua base pessoal de falhas, causas e soluções de manutenção.'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="pt-BR"><body>{children}</body></html>}
