import { defineConfig } from 'vite';
import tailwindcss from '@tailwindcss/postcss';
import { fileURLToPath } from 'node:url';
export default defineConfig({
 base:process.env.PAGES_BASE || '/RES-APP/',
 resolve:{alias:{'@':fileURLToPath(new URL('.',import.meta.url))},preserveSymlinks:false,dedupe:['react','react-dom']},
 css:{postcss:{plugins:[tailwindcss()]}},
 build:{outDir:'dist',emptyOutDir:true},
});

